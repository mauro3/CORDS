using Shapefile, PolygonOps, GeoInterface, Downloads, ZipFile
using ASCIIrasters: ASCIIrasters
#using Plots; pyplot()

# download data
dem_fl = "../dhm200.asc"
if !isfile(dem_fl)
    Downloads.download("https://data.geo.admin.ch/ch.swisstopo.digitales-hoehenmodell_25/data.zip",
                       joinpath("../dhm200.zip") )
    # do some processing, namely unzip
    r = ZipFile.Reader("../dhm200.zip")
    for f in r.files
        if f.name == "DHM200.asc"
            write(dem_fl, read(f, String));
        end
    end
    # delete zip file as we don't need it anymore
    rm("../dhm200.zip")
end
sgi_fl = "../SGI_2016_glaciers"
if !isfile(sgi_fl)
    Downloads.download("https://doi.glamos.ch/data/inventory/inventory_sgi2016_r2020.zip",
                       joinpath("../inventory_sgi2016_r2020.zip") )
    # do some processing, namely unzip
    r = ZipFile.Reader("../inventory_sgi2016_r2020.zip")
    for f in r.files
        if f.name in ["SGI_2016_glaciers.shp", "SGI_2016_glaciers.dbf"]

            write(sgi_fl*splitext(f.name)[2], read(f, String));
        end
    end
    # delete zip file as we don't need it anymore
#    rm("../inventory_sgi2016_r2020.zip")
end


# load DEM
dem, h = ASCIIrasters.read_ascii(dem_fl)
dem[dem.==-9999] .= NaN
dem = dem[end:-1:1, :]

# dem x-range, also convert to new coords
x = range(h.xll + h.dx/2, step=h.dx, length=h.ncols) .+ 2e6
y = range(h.yll + h.dx/2, step=h.dx, length=h.nrows) .+ 1e6
#heatmap(x, y, dem)


# load SGI

table = Shapefile.Table(sgi_fl)
shapes = Shapefile.shapes(table)
gid = 7518 # "Breithorngletscher (Zermatt)"
ind = findfirst(gid.==table.gid)

bbox = GeoInterface.extent(shapes[ind])
poly = GeoInterface.coordinates(shapes[ind])[1][1]
@assert poly[1]==poly[end]  # needed for inpoly

off = 1
xrng = findfirst(x.>=bbox.X[1])-off:findlast(x.<=bbox.X[2])+off
yrng = findfirst(y.>=bbox.Y[1])-off:findlast(y.<=bbox.Y[2])+off
mask = falses(length(yrng), length(xrng))
x2, y2 = x[xrng], y[yrng]
dem2 = dem[yrng, xrng]

# heatmap(x2,y2,dem2, ticks=:native)
# p = hcat(poly...)
# plot!(p[1,:], p[2,:])


for i in CartesianIndices(mask)
    if inpolygon([x2[i[2]], y2[i[1]]], reverse(poly))==1
        mask[i] = true
    end
end

# heatmap(x2,y2,mask)

## Write to asciigrids
header = (nrows=size(dem2,1), ncols=size(dem2,2), xll=Int(x2[1]-100), yll=Int(y2[1]-100), dx=200, dy=200)
ASCIIrasters.write_ascii("dhm200_cropped.asc", dem2[end:-1:1, :]; header...)
#ASCIIrasters.write_ascii("mask_breithorngletscher.asc", mask[end:-1:1, :]; nodatavalue=-9999, detecttype=true, header...)


# ## output for Breithorngletscher
# xrng = 723:730
# yrng = 127:143
# mask = Bool[0 0 0 0 0 0 0 0; 0 0 0 0 0 0 0 0; 0 0 0 1 1 1 1 0; 0 0 1 1 1 1 1 0; 0 0 1 1 1 1 1 0; 0 0 0 1 1 1 0 0; 0 0 1 1 1 1 0 0; 0 1 1 1 1 1 0 0; 0 1 1 1 1 1 0 0; 0 0 1 1 1 1 0 0; 0 1 1 1 0 1 0 0; 0 1 1 1 0 0 0 0; 0 1 1 1 0 0 0 0; 0 0 1 1 0 0 0 0; 0 0 0 1 1 0 0 0; 0 0 0 0 1 0 0 0; 0 0 0 0 0 0 0 0]
# dem2 = Float32[3881.702 3867.482 3797.095 3828.491 3894.393 3943.017 4000.713 3886.901; 3962.283 4055.096 4005.504 3957.288 4010.703 4059.225 3953.924 3742.712; 4087.92 4074.617 3925.688 3838.787 3749.083 3721.305 3823.496 3606.422; 3941.794 3831.804 3659.124 3567.024 3544.802 3509.99 3585.219 3438.38; 3764.475 3640.52 3482.416 3433.487 3411.01 3428.594 3467.992 3345.108; 3661.825 3490.113 3366.412 3328.492 3361.876 3390.317 3424.109 3269.216; 3491.387 3359.99 3265.495 3278.492 3309.481 3341.999 3231.193 3153.416; 3417.024 3212.794 3214.425 3250.714 3252.294 3283.487 3078.39 3077.32; 3252.294 3162.488 3157.697 3159.379 3174.211 3178.696 3116.311 2998.625; 3169.624 3199.797 3073.803 3067.075 3072.019 3031.703 3012.386 2922.223; 3064.425 2967.177 2975.078 2953.416 2949.797 2958.513 2890.521 2849.186; 2949.797 2899.899 2880.276 2827.32 2866.617 2856.219 2761.979 2789.298; 2942.203 2818.911 2809.176 2736.699 2721.204 2722.275 2702.091 2721.102; 2837.718 2835.475 2735.577 2709.023 2659.583 2643.019 2644.089 2638.177; 2766.821 2812.183 2779.308 2645.21 2614.018 2562.897 2579.308 2556.577; 2702.091 2743.375 2703.722 2571.103 2571.0 2537.005 2537.412 2516.719; 2651.276 2672.479 2616.515 2516.821 2521.103 2507.8 2507.902 2495.618]

## delete file
#rm("../dhm200.asc")
